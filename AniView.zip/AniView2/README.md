Nama: Samuel Bryan Parasian Sitanggang

Nim:  221401125

Lab:  4

Nama Aplikasi:  AniView

Desc:  AniView merupakan aplikasi mobile yang berfungsi untuk menampilkan list dari Anime.
Dimana jika kita memilih salah satu anime yang ada dalam list, maka akan ditampilkan gambar, 
judul, dan juga sinopsis dari anime tersebut.

Credit Sumber Asset:
-RottenTomato
-IMDb
-MyPalladium
-MyAnimeList
-Wikipedia

Screenshot Prototype:

![image](https://github.com/user-attachments/assets/5c362474-4166-40d3-9411-a5fe20728a39)

Screenshot Aplikasi

Main Activity

![image](https://github.com/user-attachments/assets/9e0807d1-f555-4613-80bb-9e1f99245456)

Detail Activity

![image](https://github.com/user-attachments/assets/5b822359-3461-49e3-bf1c-41aede714c4a)
