package com.example.aniview

data class Anime(var animeImage : Int,var heading : String)
