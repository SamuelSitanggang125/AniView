package com.example.aniview.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.aniview.DetailActivity
import com.example.aniview.R
import com.example.aniview.model.Anime

class AnimeAdapter(
    private val context: Context,
    private val animeList: List<Anime>
) : RecyclerView.Adapter<AnimeAdapter.AnimeViewHolder>() {

    inner class AnimeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val animeName: TextView = itemView.findViewById(R.id.animeNameTextView)
//        val animeImage: ImageView = itemView.findViewById(R.id.animeImageView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AnimeViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_anime, parent, false)
        return AnimeViewHolder(view)
    }

    override fun onBindViewHolder(holder: AnimeViewHolder, position: Int) {
        val anime = animeList[position]
        holder.animeName.text = anime.name

        // Contoh gambar sementara, bisa diganti dengan gambar yang lebih sesuai
//        holder.animeImage.setImageResource(R.drawable.anime_placeholder)

        holder.itemView.setOnClickListener {
            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra("ANIME_NAME", anime.name)
            intent.putExtra("ANIME_GENRE", anime.genre)
            intent.putExtra("ANIME_DESCRIPTION", anime.description)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = animeList.size
}
