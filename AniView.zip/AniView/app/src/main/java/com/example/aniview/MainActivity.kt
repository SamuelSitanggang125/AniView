package com.example.aniview

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.aniview.adapter.AnimeAdapter
import com.example.aniview.model.Anime

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val animeNames = resources.getStringArray(R.array.anime_names)
        val animeGenres = resources.getStringArray(R.array.anime_genres)
        val animeDescriptions = resources.getStringArray(R.array.anime_descriptions)

        val animeList = animeNames.indices.map {
            Anime(animeNames[it], animeGenres[it], animeDescriptions[it])
        }

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = AnimeAdapter(this, animeList)
    }
}
