package com.example.aniview

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val animeName = intent.getStringExtra("ANIME_NAME")
        val animeGenre = intent.getStringExtra("ANIME_GENRE")
        val animeDescription = intent.getStringExtra("ANIME_DESCRIPTION")

        val nameTextView: TextView = findViewById(R.id.nameTextView)
        val genreTextView: TextView = findViewById(R.id.genreTextView)
        val descriptionTextView: TextView = findViewById(R.id.descriptionTextView)

        nameTextView.text = animeName
        genreTextView.text = animeGenre
        descriptionTextView.text = animeDescription
    }
}
