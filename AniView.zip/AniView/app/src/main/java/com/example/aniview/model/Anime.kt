package com.example.aniview.model

data class Anime(val name: String, val genre: String, val description: String)

